#include <stdio.h>

int main(int argc, char **argv) {
	for (int i = 1; i < 16; i++) {
		printf("#%i: FSE2020-1 Marco Moreno\n",i);
	}

	return 0;
}
